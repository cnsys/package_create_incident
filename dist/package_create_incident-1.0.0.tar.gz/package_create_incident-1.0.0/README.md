# **Install + Configuration Guide:**

*This document should detail how to install and configure this Integration*

**NOTE:** Once you have finished development, you can automatically generate a lot of this document by using `docgen`:
```
$ resilient-sdk docgen -p <path_to_package>
```