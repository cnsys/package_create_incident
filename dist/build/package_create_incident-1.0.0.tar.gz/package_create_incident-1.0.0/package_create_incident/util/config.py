# -*- coding: utf-8 -*-

"""Generate a default configuration-file section for package_create_incident"""


def config_section_data():
    """
    Produce add the default configuration section to app.config,
    for package_create_incident when called by `resilient-circuits config [-c|-u]`
    """
    config_data = None

#    config_data = u"""[package_create_incident]
#setting=xxx
#"""
    return config_data
